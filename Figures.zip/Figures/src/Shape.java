abstract class Shape {
    public abstract int doingArea();
    int area;
}
