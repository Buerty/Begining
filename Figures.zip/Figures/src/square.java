public class square extends Shape {
    int firstside=8;


    @Override
    public int doingArea() {
        return firstside*firstside;
    }
}