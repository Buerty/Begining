public class Main {
    public static void main(String[] args){
        Rectangle n= new Rectangle();
        System.out.println(n.doingArea());
        square m= new square();
        System.out.println(m.doingArea());
    }
}
